﻿namespace LibaryProgram
{
    partial class MAksiyonForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewM1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewM1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewM1
            // 
            this.dataGridViewM1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewM1.Location = new System.Drawing.Point(-3, -2);
            this.dataGridViewM1.Name = "dataGridViewM1";
            this.dataGridViewM1.RowHeadersWidth = 51;
            this.dataGridViewM1.RowTemplate.Height = 24;
            this.dataGridViewM1.Size = new System.Drawing.Size(888, 460);
            this.dataGridViewM1.TabIndex = 0;
            // 
            // MAksiyonForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 450);
            this.Controls.Add(this.dataGridViewM1);
            this.Name = "MAksiyonForm";
            this.Text = "MAksiyon";
            this.Load += new System.EventHandler(this.MAksiyon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewM1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewM1;
    }
}