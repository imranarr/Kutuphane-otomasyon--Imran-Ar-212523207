﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibaryProgram
{
    public class IncomeDal
    {
        public List<Income> GetIncome()
        {
            List<Income> ıncomes = new List<Income>();
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlcommand = new SqlCommand("Select * From Incomes ", sqlConnection);
            SqlDataReader sqlDataReader = sqlcommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Income ıncome = new Income
                {
                    Id = Convert.ToInt32(sqlDataReader["Id"]),
                    Name = sqlDataReader["Name"].ToString(),
                    WriterName = sqlDataReader["WriterName"].ToString(),
                    WriterSurname = sqlDataReader["WriterSurname"].ToString(),
                    NumberOfPages = Convert.ToInt32(sqlDataReader["NumberOfPages"]),
                    Summary = sqlDataReader["Summary"].ToString()
                };
                ıncomes.Add(ıncome);
            }
            return ıncomes;

        }
        public void AddIncome(Income ıncome)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO Incomes (Name, WriterName, WriterSurname, NumberOfPages, Summary) VALUES (@p1,@p2,@p3,@p4,@p5)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", ıncome.Name);
            sqlCommand.Parameters.AddWithValue("@p2", ıncome.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", ıncome.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", ıncome.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", ıncome.Summary);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }
        public void UpdateIncome(Income ıncome)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Update Incomes set (Nanme, WriterName,WriterSurname,NumberOfPages, Summary,Id)VALUES(@p1,@p2,@p3,@p4,@p5,id)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", ıncome.Name);
            sqlCommand.Parameters.AddWithValue("@p2", ıncome.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", ıncome.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", ıncome.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", ıncome.Summary);
            sqlCommand.Parameters.AddWithValue("@Id", ıncome.Id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }
        public void DeleteIncome(int id)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Delete From Incomes Where Id=@p1", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }

    }
}
