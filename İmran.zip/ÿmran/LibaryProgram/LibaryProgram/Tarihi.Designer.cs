﻿namespace LibaryProgram
{
    partial class Tarihi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tarihi));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.UpdateBtnTarih = new System.Windows.Forms.Button();
            this.DelBTnTarih = new System.Windows.Forms.Button();
            this.SaveBtnTarih = new System.Windows.Forms.Button();
            this.WriterSurnameText4 = new System.Windows.Forms.TextBox();
            this.SummaryText4 = new System.Windows.Forms.TextBox();
            this.NumberPagesText4 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.WriterNameText4 = new System.Windows.Forms.TextBox();
            this.BookNameText4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(402, 152);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(386, 284);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(402, 12);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.RowTemplate.Height = 24;
            this.dataGridView5.Size = new System.Drawing.Size(386, 134);
            this.dataGridView5.TabIndex = 18;
            this.dataGridView5.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellContentClick);
            this.dataGridView5.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellContentClick);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(290, 222);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Geri";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // UpdateBtnTarih
            // 
            this.UpdateBtnTarih.Location = new System.Drawing.Point(200, 222);
            this.UpdateBtnTarih.Name = "UpdateBtnTarih";
            this.UpdateBtnTarih.Size = new System.Drawing.Size(75, 23);
            this.UpdateBtnTarih.TabIndex = 4;
            this.UpdateBtnTarih.Text = "Güncelle";
            this.UpdateBtnTarih.UseVisualStyleBackColor = true;
            this.UpdateBtnTarih.Click += new System.EventHandler(this.UpdateBtnTarih_Click);
            // 
            // DelBTnTarih
            // 
            this.DelBTnTarih.Location = new System.Drawing.Point(108, 222);
            this.DelBTnTarih.Name = "DelBTnTarih";
            this.DelBTnTarih.Size = new System.Drawing.Size(75, 23);
            this.DelBTnTarih.TabIndex = 4;
            this.DelBTnTarih.Text = "Sil";
            this.DelBTnTarih.UseVisualStyleBackColor = true;
            this.DelBTnTarih.Click += new System.EventHandler(this.DelBTnTarih_Click);
            // 
            // SaveBtnTarih
            // 
            this.SaveBtnTarih.Location = new System.Drawing.Point(10, 222);
            this.SaveBtnTarih.Name = "SaveBtnTarih";
            this.SaveBtnTarih.Size = new System.Drawing.Size(75, 23);
            this.SaveBtnTarih.TabIndex = 4;
            this.SaveBtnTarih.Text = "Kaydet";
            this.SaveBtnTarih.UseVisualStyleBackColor = true;
            this.SaveBtnTarih.Click += new System.EventHandler(this.SaveBtnTarih_Click);
            // 
            // WriterSurnameText4
            // 
            this.WriterSurnameText4.Location = new System.Drawing.Point(118, 92);
            this.WriterSurnameText4.Name = "WriterSurnameText4";
            this.WriterSurnameText4.Size = new System.Drawing.Size(145, 22);
            this.WriterSurnameText4.TabIndex = 3;
            this.WriterSurnameText4.Text = "   ";
            // 
            // SummaryText4
            // 
            this.SummaryText4.Location = new System.Drawing.Point(118, 163);
            this.SummaryText4.Name = "SummaryText4";
            this.SummaryText4.Size = new System.Drawing.Size(145, 22);
            this.SummaryText4.TabIndex = 3;
            // 
            // NumberPagesText4
            // 
            this.NumberPagesText4.Location = new System.Drawing.Point(118, 131);
            this.NumberPagesText4.Name = "NumberPagesText4";
            this.NumberPagesText4.Size = new System.Drawing.Size(145, 22);
            this.NumberPagesText4.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.UpdateBtnTarih);
            this.groupBox1.Controls.Add(this.DelBTnTarih);
            this.groupBox1.Controls.Add(this.SaveBtnTarih);
            this.groupBox1.Controls.Add(this.WriterSurnameText4);
            this.groupBox1.Controls.Add(this.SummaryText4);
            this.groupBox1.Controls.Add(this.NumberPagesText4);
            this.groupBox1.Controls.Add(this.WriterNameText4);
            this.groupBox1.Controls.Add(this.BookNameText4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.groupBox1.Location = new System.Drawing.Point(16, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(380, 254);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İşlem";
            // 
            // WriterNameText4
            // 
            this.WriterNameText4.Location = new System.Drawing.Point(118, 55);
            this.WriterNameText4.Name = "WriterNameText4";
            this.WriterNameText4.Size = new System.Drawing.Size(145, 22);
            this.WriterNameText4.TabIndex = 3;
            // 
            // BookNameText4
            // 
            this.BookNameText4.Location = new System.Drawing.Point(118, 21);
            this.BookNameText4.Name = "BookNameText4";
            this.BookNameText4.Size = new System.Drawing.Size(145, 22);
            this.BookNameText4.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-2, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Sayfa Numaras :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Özet :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Yazar Soyadı : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Yazar Adı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kitap Ad :";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(22, 49);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(285, 22);
            this.textBox5.TabIndex = 21;
            // 
            // Tarihi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox5);
            this.Name = "Tarihi";
            this.Text = "Tarihi";
            this.Load += new System.EventHandler(this.Tarihi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button UpdateBtnTarih;
        private System.Windows.Forms.Button DelBTnTarih;
        private System.Windows.Forms.Button SaveBtnTarih;
        private System.Windows.Forms.TextBox WriterSurnameText4;
        private System.Windows.Forms.TextBox SummaryText4;
        private System.Windows.Forms.TextBox NumberPagesText4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox WriterNameText4;
        private System.Windows.Forms.TextBox BookNameText4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox5;
    }
}