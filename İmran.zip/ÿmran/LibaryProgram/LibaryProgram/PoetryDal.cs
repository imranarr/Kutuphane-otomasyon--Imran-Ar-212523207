﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibaryProgram
{
    public class PoetryDal
    {
        public List<Poetry> GetPoetries()
        {
            List<Poetry> poetries = new List<Poetry>();
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlcommand = new SqlCommand("Select * From Poetries ", sqlConnection);
            SqlDataReader sqlDataReader = sqlcommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Poetry poetry = new Poetry
                {
                    Id = Convert.ToInt32(sqlDataReader["Id"]),
                    Name = sqlDataReader["Name"].ToString(),
                    WriterName = sqlDataReader["WriterName"].ToString(),
                    WriterSurname = sqlDataReader["WriterSurname"].ToString(),
                    NumberOfPages = Convert.ToInt32(sqlDataReader["NumberOfPages"]),
                    Summary = sqlDataReader["Summary"].ToString()
                };
                poetries.Add(poetry);
            }
            return poetries;

        }
        public void AddPoetries(Poetry poetry)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO Poetries (Name, WriterName, WriterSurname, NumberOfPages, Summary) VALUES (@p1,@p2,@p3,@p4,@p5)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", poetry.Name);
            sqlCommand.Parameters.AddWithValue("@p2", poetry.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", poetry.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", poetry.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", poetry.Summary);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }
        public void UpdatePoetries(Poetry poetry)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Update Poetries set (Nanme, WriterName,WriterSurname,NumberOfPages, Summary,Id)VALUES(@p1,@p2,@p3,@p4,@p5,id)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", poetry.Name);
            sqlCommand.Parameters.AddWithValue("@p2", poetry.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", poetry.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", poetry.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", poetry.Summary);
            sqlCommand.Parameters.AddWithValue("@Id", poetry.Id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }
        public void DeletePoetries(int id)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Delete From Poetries Where Id=@p1", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }

    }
}
