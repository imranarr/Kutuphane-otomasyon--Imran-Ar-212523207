﻿namespace LibaryProgram
{
    partial class DedektifiyeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DedektifiyeForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.UpdateBtnDet = new System.Windows.Forms.Button();
            this.DelBTnDet = new System.Windows.Forms.Button();
            this.SaveBtnDet = new System.Windows.Forms.Button();
            this.WriterSurnameText6 = new System.Windows.Forms.TextBox();
            this.SummaryText6 = new System.Windows.Forms.TextBox();
            this.NumberPagesText6 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.WriterNameText6 = new System.Windows.Forms.TextBox();
            this.BookNameText6 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(402, 153);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(386, 284);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(402, 13);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowHeadersWidth = 51;
            this.dataGridView6.RowTemplate.Height = 24;
            this.dataGridView6.Size = new System.Drawing.Size(386, 134);
            this.dataGridView6.TabIndex = 18;
            this.dataGridView6.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellContentClick);
            this.dataGridView6.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellContentClick);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(290, 222);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Geri";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // UpdateBtnDet
            // 
            this.UpdateBtnDet.Location = new System.Drawing.Point(200, 222);
            this.UpdateBtnDet.Name = "UpdateBtnDet";
            this.UpdateBtnDet.Size = new System.Drawing.Size(75, 23);
            this.UpdateBtnDet.TabIndex = 4;
            this.UpdateBtnDet.Text = "Güncelle";
            this.UpdateBtnDet.UseVisualStyleBackColor = true;
            this.UpdateBtnDet.Click += new System.EventHandler(this.UpdateBtnDet_Click);
            // 
            // DelBTnDet
            // 
            this.DelBTnDet.Location = new System.Drawing.Point(108, 222);
            this.DelBTnDet.Name = "DelBTnDet";
            this.DelBTnDet.Size = new System.Drawing.Size(75, 23);
            this.DelBTnDet.TabIndex = 4;
            this.DelBTnDet.Text = "Sil";
            this.DelBTnDet.UseVisualStyleBackColor = true;
            this.DelBTnDet.Click += new System.EventHandler(this.DelBTnDet_Click);
            // 
            // SaveBtnDet
            // 
            this.SaveBtnDet.Location = new System.Drawing.Point(10, 222);
            this.SaveBtnDet.Name = "SaveBtnDet";
            this.SaveBtnDet.Size = new System.Drawing.Size(75, 23);
            this.SaveBtnDet.TabIndex = 4;
            this.SaveBtnDet.Text = "Kaydet";
            this.SaveBtnDet.UseVisualStyleBackColor = true;
            this.SaveBtnDet.Click += new System.EventHandler(this.SaveBtnDet_Click);
            // 
            // WriterSurnameText6
            // 
            this.WriterSurnameText6.Location = new System.Drawing.Point(118, 92);
            this.WriterSurnameText6.Name = "WriterSurnameText6";
            this.WriterSurnameText6.Size = new System.Drawing.Size(145, 22);
            this.WriterSurnameText6.TabIndex = 3;
            this.WriterSurnameText6.Text = "   ";
            // 
            // SummaryText6
            // 
            this.SummaryText6.Location = new System.Drawing.Point(118, 163);
            this.SummaryText6.Name = "SummaryText6";
            this.SummaryText6.Size = new System.Drawing.Size(145, 22);
            this.SummaryText6.TabIndex = 3;
            // 
            // NumberPagesText6
            // 
            this.NumberPagesText6.Location = new System.Drawing.Point(118, 131);
            this.NumberPagesText6.Name = "NumberPagesText6";
            this.NumberPagesText6.Size = new System.Drawing.Size(145, 22);
            this.NumberPagesText6.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.UpdateBtnDet);
            this.groupBox1.Controls.Add(this.DelBTnDet);
            this.groupBox1.Controls.Add(this.SaveBtnDet);
            this.groupBox1.Controls.Add(this.WriterSurnameText6);
            this.groupBox1.Controls.Add(this.SummaryText6);
            this.groupBox1.Controls.Add(this.NumberPagesText6);
            this.groupBox1.Controls.Add(this.WriterNameText6);
            this.groupBox1.Controls.Add(this.BookNameText6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.groupBox1.Location = new System.Drawing.Point(12, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(380, 254);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İşlem";
            // 
            // WriterNameText6
            // 
            this.WriterNameText6.Location = new System.Drawing.Point(118, 55);
            this.WriterNameText6.Name = "WriterNameText6";
            this.WriterNameText6.Size = new System.Drawing.Size(145, 22);
            this.WriterNameText6.TabIndex = 3;
            // 
            // BookNameText6
            // 
            this.BookNameText6.Location = new System.Drawing.Point(118, 21);
            this.BookNameText6.Name = "BookNameText6";
            this.BookNameText6.Size = new System.Drawing.Size(145, 22);
            this.BookNameText6.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-2, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Sayfa Numaras :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Özet :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Yazar Soyadı : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Yazar Adı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kitap Ad :";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(22, 50);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(285, 22);
            this.textBox6.TabIndex = 21;
            // 
            // DedektifiyeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox6);
            this.Name = "DedektifiyeForm";
            this.Text = "Dedektifiye";
            this.Load += new System.EventHandler(this.DedektifiyeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button UpdateBtnDet;
        private System.Windows.Forms.Button DelBTnDet;
        private System.Windows.Forms.Button SaveBtnDet;
        private System.Windows.Forms.TextBox WriterSurnameText6;
        private System.Windows.Forms.TextBox SummaryText6;
        private System.Windows.Forms.TextBox NumberPagesText6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox WriterNameText6;
        private System.Windows.Forms.TextBox BookNameText6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox6;
    }
}