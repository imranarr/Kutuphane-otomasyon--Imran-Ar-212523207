﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibaryProgram
{
    public class DetectiveDal
    {
        public List<Detective> GetDetectives()
        {
            List<Detective> detectives = new List<Detective>();
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlcommand = new SqlCommand("Select * From Detectives ", sqlConnection);
            SqlDataReader sqlDataReader = sqlcommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Detective detective = new Detective
                {
                    Id = Convert.ToInt32(sqlDataReader["Id"]),
                    Name = sqlDataReader["Name"].ToString(),
                    WriterName = sqlDataReader["WriterName"].ToString(),
                    WriterSurname = sqlDataReader["WriterSurname"].ToString(),
                    NumberOfPages = Convert.ToInt32(sqlDataReader["NumberOfPages"]),
                    Summary = sqlDataReader["Summary"].ToString()
                };
                detectives.Add(detective);
            }
            return detectives;

        }
        public void AddDetective(Detective detective)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO Detectives (Name, WriterName, WriterSurname, NumberOfPages, Summary) VALUES (@p1,@p2,@p3,@p4,@p5)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", detective.Name);
            sqlCommand.Parameters.AddWithValue("@p2", detective.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", detective.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", detective.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", detective.Summary);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }
        public void UpdateDetective(Fear fear)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat;Initial Catalog= DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Update Detectives set (Nanme, WriterName,WriterSurname,NumberOfPages, Summary,Id)VALUES(@p1,@p2,@p3,@p4,@p5,id)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", fear.Name);
            sqlCommand.Parameters.AddWithValue("@p2", fear.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", fear.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", fear.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", fear.Summary);
            sqlCommand.Parameters.AddWithValue("@Id", fear.Id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }
        public void DeleteDetective(int id)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat;Initial Catalog= DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Delete From Detectives Where Id=@p1", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }

    }
}
