﻿namespace LibaryProgram
{
    partial class GerilimForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GerilimForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.UpdateBtnIncome = new System.Windows.Forms.Button();
            this.DelBTnIncome = new System.Windows.Forms.Button();
            this.SaveBtnIncome = new System.Windows.Forms.Button();
            this.WriterSurnameText8 = new System.Windows.Forms.TextBox();
            this.SummaryText8 = new System.Windows.Forms.TextBox();
            this.NumberPagesText8 = new System.Windows.Forms.TextBox();
            this.WriterNameText8 = new System.Windows.Forms.TextBox();
            this.BookNameText8 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button9);
            this.groupBox1.Controls.Add(this.UpdateBtnIncome);
            this.groupBox1.Controls.Add(this.DelBTnIncome);
            this.groupBox1.Controls.Add(this.SaveBtnIncome);
            this.groupBox1.Controls.Add(this.WriterSurnameText8);
            this.groupBox1.Controls.Add(this.SummaryText8);
            this.groupBox1.Controls.Add(this.NumberPagesText8);
            this.groupBox1.Controls.Add(this.WriterNameText8);
            this.groupBox1.Controls.Add(this.BookNameText8);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.groupBox1.Location = new System.Drawing.Point(16, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(380, 254);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İşlem";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(290, 222);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 4;
            this.button9.Text = "Geri";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // UpdateBtnIncome
            // 
            this.UpdateBtnIncome.Location = new System.Drawing.Point(200, 222);
            this.UpdateBtnIncome.Name = "UpdateBtnIncome";
            this.UpdateBtnIncome.Size = new System.Drawing.Size(75, 23);
            this.UpdateBtnIncome.TabIndex = 4;
            this.UpdateBtnIncome.Text = "Güncelle";
            this.UpdateBtnIncome.UseVisualStyleBackColor = true;
            this.UpdateBtnIncome.Click += new System.EventHandler(this.UpdateBtnIncome_Click);
            // 
            // DelBTnIncome
            // 
            this.DelBTnIncome.Location = new System.Drawing.Point(108, 222);
            this.DelBTnIncome.Name = "DelBTnIncome";
            this.DelBTnIncome.Size = new System.Drawing.Size(75, 23);
            this.DelBTnIncome.TabIndex = 4;
            this.DelBTnIncome.Text = "Sil";
            this.DelBTnIncome.UseVisualStyleBackColor = true;
            this.DelBTnIncome.Click += new System.EventHandler(this.DelBTnIncome_Click);
            // 
            // SaveBtnIncome
            // 
            this.SaveBtnIncome.Location = new System.Drawing.Point(10, 222);
            this.SaveBtnIncome.Name = "SaveBtnIncome";
            this.SaveBtnIncome.Size = new System.Drawing.Size(75, 23);
            this.SaveBtnIncome.TabIndex = 4;
            this.SaveBtnIncome.Text = "Kaydet";
            this.SaveBtnIncome.UseVisualStyleBackColor = true;
            this.SaveBtnIncome.Click += new System.EventHandler(this.SaveBtnIncome_Click);
            // 
            // WriterSurnameText8
            // 
            this.WriterSurnameText8.Location = new System.Drawing.Point(118, 92);
            this.WriterSurnameText8.Name = "WriterSurnameText8";
            this.WriterSurnameText8.Size = new System.Drawing.Size(145, 22);
            this.WriterSurnameText8.TabIndex = 3;
            this.WriterSurnameText8.Text = "   ";
            // 
            // SummaryText8
            // 
            this.SummaryText8.Location = new System.Drawing.Point(118, 163);
            this.SummaryText8.Name = "SummaryText8";
            this.SummaryText8.Size = new System.Drawing.Size(145, 22);
            this.SummaryText8.TabIndex = 3;
            // 
            // NumberPagesText8
            // 
            this.NumberPagesText8.Location = new System.Drawing.Point(118, 131);
            this.NumberPagesText8.Name = "NumberPagesText8";
            this.NumberPagesText8.Size = new System.Drawing.Size(145, 22);
            this.NumberPagesText8.TabIndex = 3;
            // 
            // WriterNameText8
            // 
            this.WriterNameText8.Location = new System.Drawing.Point(118, 55);
            this.WriterNameText8.Name = "WriterNameText8";
            this.WriterNameText8.Size = new System.Drawing.Size(145, 22);
            this.WriterNameText8.TabIndex = 3;
            // 
            // BookNameText8
            // 
            this.BookNameText8.Location = new System.Drawing.Point(118, 21);
            this.BookNameText8.Name = "BookNameText8";
            this.BookNameText8.Size = new System.Drawing.Size(145, 22);
            this.BookNameText8.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-2, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Sayfa Numaras :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Özet :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Yazar Soyadı : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Yazar Adı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kitap Ad :";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(22, 50);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(285, 22);
            this.textBox9.TabIndex = 25;
            // 
            // dataGridView9
            // 
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Location = new System.Drawing.Point(402, 13);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.RowHeadersWidth = 51;
            this.dataGridView9.RowTemplate.Height = 24;
            this.dataGridView9.Size = new System.Drawing.Size(386, 134);
            this.dataGridView9.TabIndex = 22;
            this.dataGridView9.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView9_CellContentClick);
            this.dataGridView9.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView9_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(402, 153);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(386, 284);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // GerilimForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.dataGridView9);
            this.Controls.Add(this.pictureBox1);
            this.Name = "GerilimForm";
            this.Text = "Gerilim";
            this.Load += new System.EventHandler(this.GerilimForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button UpdateBtnIncome;
        private System.Windows.Forms.Button DelBTnIncome;
        private System.Windows.Forms.Button SaveBtnIncome;
        private System.Windows.Forms.TextBox WriterSurnameText8;
        private System.Windows.Forms.TextBox SummaryText8;
        private System.Windows.Forms.TextBox NumberPagesText8;
        private System.Windows.Forms.TextBox WriterNameText8;
        private System.Windows.Forms.TextBox BookNameText8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}