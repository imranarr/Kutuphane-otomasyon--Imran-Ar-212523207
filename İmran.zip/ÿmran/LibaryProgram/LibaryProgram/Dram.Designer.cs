﻿namespace LibaryProgram
{
    partial class DramForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DramForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.UpdateBtnDram = new System.Windows.Forms.Button();
            this.DelBTnDram = new System.Windows.Forms.Button();
            this.SaveBtnDram = new System.Windows.Forms.Button();
            this.WriterSurnameText1 = new System.Windows.Forms.TextBox();
            this.SummaryText1 = new System.Windows.Forms.TextBox();
            this.NumberPagesText1 = new System.Windows.Forms.TextBox();
            this.WriterNameText1 = new System.Windows.Forms.TextBox();
            this.BookNameText1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.UpdateBtnDram);
            this.groupBox1.Controls.Add(this.DelBTnDram);
            this.groupBox1.Controls.Add(this.SaveBtnDram);
            this.groupBox1.Controls.Add(this.WriterSurnameText1);
            this.groupBox1.Controls.Add(this.SummaryText1);
            this.groupBox1.Controls.Add(this.NumberPagesText1);
            this.groupBox1.Controls.Add(this.WriterNameText1);
            this.groupBox1.Controls.Add(this.BookNameText1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(380, 254);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İşlem";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(290, 222);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Geri";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // UpdateBtnDram
            // 
            this.UpdateBtnDram.Location = new System.Drawing.Point(200, 222);
            this.UpdateBtnDram.Name = "UpdateBtnDram";
            this.UpdateBtnDram.Size = new System.Drawing.Size(75, 23);
            this.UpdateBtnDram.TabIndex = 4;
            this.UpdateBtnDram.Text = "Güncelle";
            this.UpdateBtnDram.UseVisualStyleBackColor = true;
            this.UpdateBtnDram.Click += new System.EventHandler(this.UpdateBtnDram_Click);
            // 
            // DelBTnDram
            // 
            this.DelBTnDram.Location = new System.Drawing.Point(108, 222);
            this.DelBTnDram.Name = "DelBTnDram";
            this.DelBTnDram.Size = new System.Drawing.Size(75, 23);
            this.DelBTnDram.TabIndex = 4;
            this.DelBTnDram.Text = "Sil";
            this.DelBTnDram.UseVisualStyleBackColor = true;
            this.DelBTnDram.Click += new System.EventHandler(this.DelBTnDram_Click);
            // 
            // SaveBtnDram
            // 
            this.SaveBtnDram.Location = new System.Drawing.Point(10, 222);
            this.SaveBtnDram.Name = "SaveBtnDram";
            this.SaveBtnDram.Size = new System.Drawing.Size(75, 23);
            this.SaveBtnDram.TabIndex = 4;
            this.SaveBtnDram.Text = "Kaydet";
            this.SaveBtnDram.UseVisualStyleBackColor = true;
            this.SaveBtnDram.Click += new System.EventHandler(this.SaveBtnDram_Click);
            // 
            // WriterSurnameText1
            // 
            this.WriterSurnameText1.Location = new System.Drawing.Point(118, 92);
            this.WriterSurnameText1.Name = "WriterSurnameText1";
            this.WriterSurnameText1.Size = new System.Drawing.Size(145, 22);
            this.WriterSurnameText1.TabIndex = 3;
            this.WriterSurnameText1.Text = "   ";
            // 
            // SummaryText1
            // 
            this.SummaryText1.Location = new System.Drawing.Point(118, 163);
            this.SummaryText1.Name = "SummaryText1";
            this.SummaryText1.Size = new System.Drawing.Size(145, 22);
            this.SummaryText1.TabIndex = 3;
            // 
            // NumberPagesText1
            // 
            this.NumberPagesText1.Location = new System.Drawing.Point(118, 131);
            this.NumberPagesText1.Name = "NumberPagesText1";
            this.NumberPagesText1.Size = new System.Drawing.Size(145, 22);
            this.NumberPagesText1.TabIndex = 3;
            // 
            // WriterNameText1
            // 
            this.WriterNameText1.Location = new System.Drawing.Point(118, 55);
            this.WriterNameText1.Name = "WriterNameText1";
            this.WriterNameText1.Size = new System.Drawing.Size(145, 22);
            this.WriterNameText1.TabIndex = 3;
            // 
            // BookNameText1
            // 
            this.BookNameText1.Location = new System.Drawing.Point(118, 21);
            this.BookNameText1.Name = "BookNameText1";
            this.BookNameText1.Size = new System.Drawing.Size(145, 22);
            this.BookNameText1.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-2, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Sayfa Numaras :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Özet :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Yazar Soyadı : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Yazar Adı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kitap Ad :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(402, 143);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(386, 356);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(402, 12);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(386, 127);
            this.dataGridView2.TabIndex = 6;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(22, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(285, 22);
            this.textBox2.TabIndex = 9;
            // 
            // DramForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 497);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.textBox2);
            this.Name = "DramForm";
            this.Text = "Dram";
            this.Load += new System.EventHandler(this.DramForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button UpdateBtnDram;
        private System.Windows.Forms.Button DelBTnDram;
        private System.Windows.Forms.Button SaveBtnDram;
        private System.Windows.Forms.TextBox WriterSurnameText1;
        private System.Windows.Forms.TextBox SummaryText1;
        private System.Windows.Forms.TextBox NumberPagesText1;
        private System.Windows.Forms.TextBox WriterNameText1;
        private System.Windows.Forms.TextBox BookNameText1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox textBox2;
    }
}