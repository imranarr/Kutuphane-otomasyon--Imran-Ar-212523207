﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibaryProgram
{
    public class HistoryDal
    {
        public List<History> GetAllHistory()
        {
            List<History> histories = new List<History>();
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlcommand = new SqlCommand("Select * From Histories ", sqlConnection);
            SqlDataReader sqlDataReader = sqlcommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                History history = new History
                {
                    Id = Convert.ToInt32(sqlDataReader["Id"]),
                    Name = sqlDataReader["Name"].ToString(),
                    WriterName = sqlDataReader["WriterName"].ToString(),
                    WriterSurname = sqlDataReader["WriterSurname"].ToString(),
                    NumberOfPages = Convert.ToInt32(sqlDataReader["NumberOfPages"]),
                    Summary = sqlDataReader["Summary"].ToString()
                };
                histories.Add(history);
            }
            return histories;

        }
        public void AddHistory(History history)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO Histories (Name, WriterName, WriterSurname, NumberOfPages, Summary) VALUES (@p1,@p2,@p3,@p4,@p5)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", history.Name);
            sqlCommand.Parameters.AddWithValue("@p2", history.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", history.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", history.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", history.Summary);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }
        public void UpdateHistory(History history)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Update Histories set (Nanme, WriterName,WriterSurname,NumberOfPages, Summary,Id)VALUES(@p1,@p2,@p3,@p4,@p5,id)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", history.Name);
            sqlCommand.Parameters.AddWithValue("@p2", history.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", history.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", history.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", history.Summary);
            sqlCommand.Parameters.AddWithValue("@Id", history.Id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }
        public void DeleteHistory(int id)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Delete From Histories Where Id=@p1", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }

    }
}
