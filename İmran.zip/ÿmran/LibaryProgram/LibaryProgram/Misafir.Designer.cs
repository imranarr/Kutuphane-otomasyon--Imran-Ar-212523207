﻿namespace LibaryProgram
{
    partial class Misafir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Misafir));
            this.Geribtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DramPic1 = new System.Windows.Forms.PictureBox();
            this.GerilimPic1 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.Aksiyonpic1 = new System.Windows.Forms.PictureBox();
            this.ŞiirPic1 = new System.Windows.Forms.PictureBox();
            this.AşkPic1 = new System.Windows.Forms.PictureBox();
            this.KorkuPic1 = new System.Windows.Forms.PictureBox();
            this.DedektifiyePic1 = new System.Windows.Forms.PictureBox();
            this.TarihiPic1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.DramPic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GerilimPic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Aksiyonpic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ŞiirPic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AşkPic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorkuPic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DedektifiyePic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TarihiPic1)).BeginInit();
            this.SuspendLayout();
            // 
            // Geribtn
            // 
            this.Geribtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Geribtn.Location = new System.Drawing.Point(302, 502);
            this.Geribtn.Name = "Geribtn";
            this.Geribtn.Size = new System.Drawing.Size(180, 46);
            this.Geribtn.TabIndex = 22;
            this.Geribtn.Text = "Geri";
            this.Geribtn.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(-8, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(567, 69);
            this.label9.TabIndex = 21;
            this.label9.Text = "Kitap Konusu Seçin";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(719, 463);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "Şiir ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(719, 291);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "Korku";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(489, 463);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "Gerilim";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(489, 291);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 20);
            this.label3.TabIndex = 16;
            this.label3.Text = "Aşk";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(49, 463);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Tarihi";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(261, 463);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "Dedektifye";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(278, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "Dram";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(38, 291);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Aksiyon";
            // 
            // DramPic1
            // 
            this.DramPic1.Image = ((System.Drawing.Image)(resources.GetObject("DramPic1.Image")));
            this.DramPic1.Location = new System.Drawing.Point(193, 138);
            this.DramPic1.Name = "DramPic1";
            this.DramPic1.Size = new System.Drawing.Size(205, 150);
            this.DramPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DramPic1.TabIndex = 11;
            this.DramPic1.TabStop = false;
            this.DramPic1.Click += new System.EventHandler(this.DramPic1_Click);
            // 
            // GerilimPic1
            // 
            this.GerilimPic1.Image = ((System.Drawing.Image)(resources.GetObject("GerilimPic1.Image")));
            this.GerilimPic1.Location = new System.Drawing.Point(404, 314);
            this.GerilimPic1.Name = "GerilimPic1";
            this.GerilimPic1.Size = new System.Drawing.Size(205, 146);
            this.GerilimPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GerilimPic1.TabIndex = 10;
            this.GerilimPic1.TabStop = false;
            this.GerilimPic1.Click += new System.EventHandler(this.GerilimPic1_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(565, 13);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(252, 119);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 9;
            this.pictureBox9.TabStop = false;
            // 
            // Aksiyonpic1
            // 
            this.Aksiyonpic1.Image = ((System.Drawing.Image)(resources.GetObject("Aksiyonpic1.Image")));
            this.Aksiyonpic1.Location = new System.Drawing.Point(-28, 138);
            this.Aksiyonpic1.Name = "Aksiyonpic1";
            this.Aksiyonpic1.Size = new System.Drawing.Size(215, 150);
            this.Aksiyonpic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Aksiyonpic1.TabIndex = 8;
            this.Aksiyonpic1.TabStop = false;
            this.Aksiyonpic1.Click += new System.EventHandler(this.Aksiyonpic1_Click);
            // 
            // ŞiirPic1
            // 
            this.ŞiirPic1.Image = ((System.Drawing.Image)(resources.GetObject("ŞiirPic1.Image")));
            this.ŞiirPic1.Location = new System.Drawing.Point(615, 314);
            this.ŞiirPic1.Name = "ŞiirPic1";
            this.ŞiirPic1.Size = new System.Drawing.Size(205, 146);
            this.ŞiirPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ŞiirPic1.TabIndex = 7;
            this.ŞiirPic1.TabStop = false;
            this.ŞiirPic1.Click += new System.EventHandler(this.ŞiirPic1_Click);
            // 
            // AşkPic1
            // 
            this.AşkPic1.Image = ((System.Drawing.Image)(resources.GetObject("AşkPic1.Image")));
            this.AşkPic1.Location = new System.Drawing.Point(404, 138);
            this.AşkPic1.Name = "AşkPic1";
            this.AşkPic1.Size = new System.Drawing.Size(205, 150);
            this.AşkPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AşkPic1.TabIndex = 6;
            this.AşkPic1.TabStop = false;
            this.AşkPic1.Click += new System.EventHandler(this.AşkPic1_Click);
            // 
            // KorkuPic1
            // 
            this.KorkuPic1.Image = ((System.Drawing.Image)(resources.GetObject("KorkuPic1.Image")));
            this.KorkuPic1.Location = new System.Drawing.Point(615, 138);
            this.KorkuPic1.Name = "KorkuPic1";
            this.KorkuPic1.Size = new System.Drawing.Size(205, 150);
            this.KorkuPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.KorkuPic1.TabIndex = 5;
            this.KorkuPic1.TabStop = false;
            this.KorkuPic1.Click += new System.EventHandler(this.KorkuPic1_Click);
            // 
            // DedektifiyePic1
            // 
            this.DedektifiyePic1.Image = ((System.Drawing.Image)(resources.GetObject("DedektifiyePic1.Image")));
            this.DedektifiyePic1.Location = new System.Drawing.Point(193, 314);
            this.DedektifiyePic1.Name = "DedektifiyePic1";
            this.DedektifiyePic1.Size = new System.Drawing.Size(205, 146);
            this.DedektifiyePic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DedektifiyePic1.TabIndex = 12;
            this.DedektifiyePic1.TabStop = false;
            this.DedektifiyePic1.Click += new System.EventHandler(this.DedektifiyePic1_Click);
            // 
            // TarihiPic1
            // 
            this.TarihiPic1.Image = ((System.Drawing.Image)(resources.GetObject("TarihiPic1.Image")));
            this.TarihiPic1.Location = new System.Drawing.Point(-28, 314);
            this.TarihiPic1.Name = "TarihiPic1";
            this.TarihiPic1.Size = new System.Drawing.Size(215, 146);
            this.TarihiPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TarihiPic1.TabIndex = 4;
            this.TarihiPic1.TabStop = false;
            this.TarihiPic1.Click += new System.EventHandler(this.TarihiPic1_Click);
            // 
            // Misafir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 566);
            this.Controls.Add(this.Geribtn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DramPic1);
            this.Controls.Add(this.GerilimPic1);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.Aksiyonpic1);
            this.Controls.Add(this.ŞiirPic1);
            this.Controls.Add(this.AşkPic1);
            this.Controls.Add(this.KorkuPic1);
            this.Controls.Add(this.DedektifiyePic1);
            this.Controls.Add(this.TarihiPic1);
            this.Name = "Misafir";
            this.Text = "Misafir";
            ((System.ComponentModel.ISupportInitialize)(this.DramPic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GerilimPic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Aksiyonpic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ŞiirPic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AşkPic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorkuPic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DedektifiyePic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TarihiPic1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Geribtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox DramPic1;
        private System.Windows.Forms.PictureBox GerilimPic1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox Aksiyonpic1;
        private System.Windows.Forms.PictureBox ŞiirPic1;
        private System.Windows.Forms.PictureBox AşkPic1;
        private System.Windows.Forms.PictureBox KorkuPic1;
        private System.Windows.Forms.PictureBox DedektifiyePic1;
        private System.Windows.Forms.PictureBox TarihiPic1;
    }
}