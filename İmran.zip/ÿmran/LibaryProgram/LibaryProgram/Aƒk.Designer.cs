﻿namespace LibaryProgram
{
    partial class AşkForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AşkForm));
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.UpdateBtnAşk = new System.Windows.Forms.Button();
            this.DelBTnAşk = new System.Windows.Forms.Button();
            this.SaveBtnAşk = new System.Windows.Forms.Button();
            this.WriterSurnameText2 = new System.Windows.Forms.TextBox();
            this.SummaryText2 = new System.Windows.Forms.TextBox();
            this.NumberPagesText2 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.WriterNameText2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.BookNameText2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(22, 37);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(285, 22);
            this.textBox3.TabIndex = 13;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(290, 222);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "Geri";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // UpdateBtnAşk
            // 
            this.UpdateBtnAşk.Location = new System.Drawing.Point(200, 222);
            this.UpdateBtnAşk.Name = "UpdateBtnAşk";
            this.UpdateBtnAşk.Size = new System.Drawing.Size(75, 23);
            this.UpdateBtnAşk.TabIndex = 4;
            this.UpdateBtnAşk.Text = "Güncelle";
            this.UpdateBtnAşk.UseVisualStyleBackColor = true;
            this.UpdateBtnAşk.Click += new System.EventHandler(this.UpdateBtnAşk_Click_1);
            // 
            // DelBTnAşk
            // 
            this.DelBTnAşk.Location = new System.Drawing.Point(108, 222);
            this.DelBTnAşk.Name = "DelBTnAşk";
            this.DelBTnAşk.Size = new System.Drawing.Size(75, 23);
            this.DelBTnAşk.TabIndex = 4;
            this.DelBTnAşk.Text = "Sil";
            this.DelBTnAşk.UseVisualStyleBackColor = true;
            this.DelBTnAşk.Click += new System.EventHandler(this.DelBTnAşk_Click_1);
            // 
            // SaveBtnAşk
            // 
            this.SaveBtnAşk.Location = new System.Drawing.Point(10, 222);
            this.SaveBtnAşk.Name = "SaveBtnAşk";
            this.SaveBtnAşk.Size = new System.Drawing.Size(75, 23);
            this.SaveBtnAşk.TabIndex = 4;
            this.SaveBtnAşk.Text = "Kaydet";
            this.SaveBtnAşk.UseVisualStyleBackColor = true;
            this.SaveBtnAşk.Click += new System.EventHandler(this.SaveBtnAşk_Click_1);
            // 
            // WriterSurnameText2
            // 
            this.WriterSurnameText2.Location = new System.Drawing.Point(118, 92);
            this.WriterSurnameText2.Name = "WriterSurnameText2";
            this.WriterSurnameText2.Size = new System.Drawing.Size(145, 22);
            this.WriterSurnameText2.TabIndex = 3;
            this.WriterSurnameText2.Text = "   ";
            // 
            // SummaryText2
            // 
            this.SummaryText2.Location = new System.Drawing.Point(118, 163);
            this.SummaryText2.Name = "SummaryText2";
            this.SummaryText2.Size = new System.Drawing.Size(145, 22);
            this.SummaryText2.TabIndex = 3;
            // 
            // NumberPagesText2
            // 
            this.NumberPagesText2.Location = new System.Drawing.Point(118, 131);
            this.NumberPagesText2.Name = "NumberPagesText2";
            this.NumberPagesText2.Size = new System.Drawing.Size(145, 22);
            this.NumberPagesText2.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(402, 140);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(386, 284);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // WriterNameText2
            // 
            this.WriterNameText2.Location = new System.Drawing.Point(118, 55);
            this.WriterNameText2.Name = "WriterNameText2";
            this.WriterNameText2.Size = new System.Drawing.Size(145, 22);
            this.WriterNameText2.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-2, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Sayfa Numaras :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Özet :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Yazar Soyadı : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Yazar Adı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kitap Ad :";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(402, 12);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(386, 127);
            this.dataGridView3.TabIndex = 10;
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // BookNameText2
            // 
            this.BookNameText2.Location = new System.Drawing.Point(118, 21);
            this.BookNameText2.Name = "BookNameText2";
            this.BookNameText2.Size = new System.Drawing.Size(145, 22);
            this.BookNameText2.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.UpdateBtnAşk);
            this.groupBox1.Controls.Add(this.DelBTnAşk);
            this.groupBox1.Controls.Add(this.SaveBtnAşk);
            this.groupBox1.Controls.Add(this.WriterSurnameText2);
            this.groupBox1.Controls.Add(this.SummaryText2);
            this.groupBox1.Controls.Add(this.NumberPagesText2);
            this.groupBox1.Controls.Add(this.WriterNameText2);
            this.groupBox1.Controls.Add(this.BookNameText2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.groupBox1.Location = new System.Drawing.Point(12, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(380, 254);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İşlem";
            // 
            // AşkForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 493);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox3);
            this.Name = "AşkForm";
            this.Text = "Aşk";
            this.Load += new System.EventHandler(this.AşkForm_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button UpdateBtnAşk;
        private System.Windows.Forms.Button DelBTnAşk;
        private System.Windows.Forms.Button SaveBtnAşk;
        private System.Windows.Forms.TextBox WriterSurnameText2;
        private System.Windows.Forms.TextBox SummaryText2;
        private System.Windows.Forms.TextBox NumberPagesText2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox WriterNameText2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TextBox BookNameText2;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}