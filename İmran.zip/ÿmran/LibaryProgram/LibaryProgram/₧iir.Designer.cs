﻿namespace LibaryProgram
{
    partial class ŞiirForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ŞiirForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button10 = new System.Windows.Forms.Button();
            this.UpdateBtnŞiir = new System.Windows.Forms.Button();
            this.DelBTnŞiir = new System.Windows.Forms.Button();
            this.SaveBtnŞiir = new System.Windows.Forms.Button();
            this.WriterSurnameText9 = new System.Windows.Forms.TextBox();
            this.SummaryText9 = new System.Windows.Forms.TextBox();
            this.NumberPagesText9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.WriterNameText9 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.BookNameText9 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(400, 154);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(386, 284);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(290, 222);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 4;
            this.button10.Text = "Geri";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // UpdateBtnŞiir
            // 
            this.UpdateBtnŞiir.Location = new System.Drawing.Point(200, 222);
            this.UpdateBtnŞiir.Name = "UpdateBtnŞiir";
            this.UpdateBtnŞiir.Size = new System.Drawing.Size(75, 23);
            this.UpdateBtnŞiir.TabIndex = 4;
            this.UpdateBtnŞiir.Text = "Güncelle";
            this.UpdateBtnŞiir.UseVisualStyleBackColor = true;
            this.UpdateBtnŞiir.Click += new System.EventHandler(this.UpdateBtnŞiir_Click);
            // 
            // DelBTnŞiir
            // 
            this.DelBTnŞiir.Location = new System.Drawing.Point(108, 222);
            this.DelBTnŞiir.Name = "DelBTnŞiir";
            this.DelBTnŞiir.Size = new System.Drawing.Size(75, 23);
            this.DelBTnŞiir.TabIndex = 4;
            this.DelBTnŞiir.Text = "Sil";
            this.DelBTnŞiir.UseVisualStyleBackColor = true;
            this.DelBTnŞiir.Click += new System.EventHandler(this.DelBTnŞiir_Click);
            // 
            // SaveBtnŞiir
            // 
            this.SaveBtnŞiir.Location = new System.Drawing.Point(10, 222);
            this.SaveBtnŞiir.Name = "SaveBtnŞiir";
            this.SaveBtnŞiir.Size = new System.Drawing.Size(75, 23);
            this.SaveBtnŞiir.TabIndex = 4;
            this.SaveBtnŞiir.Text = "Kaydet";
            this.SaveBtnŞiir.UseVisualStyleBackColor = true;
            this.SaveBtnŞiir.Click += new System.EventHandler(this.SaveBtnŞiir_Click);
            // 
            // WriterSurnameText9
            // 
            this.WriterSurnameText9.Location = new System.Drawing.Point(118, 92);
            this.WriterSurnameText9.Name = "WriterSurnameText9";
            this.WriterSurnameText9.Size = new System.Drawing.Size(145, 22);
            this.WriterSurnameText9.TabIndex = 3;
            this.WriterSurnameText9.Text = "   ";
            // 
            // SummaryText9
            // 
            this.SummaryText9.Location = new System.Drawing.Point(118, 163);
            this.SummaryText9.Name = "SummaryText9";
            this.SummaryText9.Size = new System.Drawing.Size(145, 22);
            this.SummaryText9.TabIndex = 3;
            // 
            // NumberPagesText9
            // 
            this.NumberPagesText9.Location = new System.Drawing.Point(118, 131);
            this.NumberPagesText9.Name = "NumberPagesText9";
            this.NumberPagesText9.Size = new System.Drawing.Size(145, 22);
            this.NumberPagesText9.TabIndex = 3;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(441, 295);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(285, 22);
            this.textBox10.TabIndex = 29;
            // 
            // WriterNameText9
            // 
            this.WriterNameText9.Location = new System.Drawing.Point(118, 55);
            this.WriterNameText9.Name = "WriterNameText9";
            this.WriterNameText9.Size = new System.Drawing.Size(145, 22);
            this.WriterNameText9.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-2, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Sayfa Numaras :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Özet :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Yazar Soyadı : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Yazar Adı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kitap Ad :";
            // 
            // dataGridView10
            // 
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Location = new System.Drawing.Point(400, 14);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.RowHeadersWidth = 51;
            this.dataGridView10.RowTemplate.Height = 24;
            this.dataGridView10.Size = new System.Drawing.Size(386, 134);
            this.dataGridView10.TabIndex = 26;
            this.dataGridView10.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView10_CellContentClick);
            // 
            // BookNameText9
            // 
            this.BookNameText9.Location = new System.Drawing.Point(118, 21);
            this.BookNameText9.Name = "BookNameText9";
            this.BookNameText9.Size = new System.Drawing.Size(145, 22);
            this.BookNameText9.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button10);
            this.groupBox1.Controls.Add(this.UpdateBtnŞiir);
            this.groupBox1.Controls.Add(this.DelBTnŞiir);
            this.groupBox1.Controls.Add(this.SaveBtnŞiir);
            this.groupBox1.Controls.Add(this.WriterSurnameText9);
            this.groupBox1.Controls.Add(this.SummaryText9);
            this.groupBox1.Controls.Add(this.NumberPagesText9);
            this.groupBox1.Controls.Add(this.WriterNameText9);
            this.groupBox1.Controls.Add(this.BookNameText9);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(380, 254);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İşlem";
            // 
            // ŞiirForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView10);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox10);
            this.Name = "ŞiirForm";
            this.Text = "Şiir";
            this.Load += new System.EventHandler(this.ŞiirForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button UpdateBtnŞiir;
        private System.Windows.Forms.Button DelBTnŞiir;
        private System.Windows.Forms.Button SaveBtnŞiir;
        private System.Windows.Forms.TextBox WriterSurnameText9;
        private System.Windows.Forms.TextBox SummaryText9;
        private System.Windows.Forms.TextBox NumberPagesText9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox WriterNameText9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.TextBox BookNameText9;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}