﻿namespace LibaryProgram
{
    partial class MenüForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenüForm));
            this.TarihiPic = new System.Windows.Forms.PictureBox();
            this.AşkPic = new System.Windows.Forms.PictureBox();
            this.ŞiirPic = new System.Windows.Forms.PictureBox();
            this.Aksiyonpic = new System.Windows.Forms.PictureBox();
            this.GerilimPic = new System.Windows.Forms.PictureBox();
            this.DramPic = new System.Windows.Forms.PictureBox();
            this.KorkuPic = new System.Windows.Forms.PictureBox();
            this.DedektifiyePic = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TarihiPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AşkPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ŞiirPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Aksiyonpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GerilimPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DramPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorkuPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DedektifiyePic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // TarihiPic
            // 
            this.TarihiPic.Image = ((System.Drawing.Image)(resources.GetObject("TarihiPic.Image")));
            this.TarihiPic.Location = new System.Drawing.Point(9, 311);
            this.TarihiPic.Name = "TarihiPic";
            this.TarihiPic.Size = new System.Drawing.Size(215, 146);
            this.TarihiPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TarihiPic.TabIndex = 0;
            this.TarihiPic.TabStop = false;
            this.TarihiPic.Click += new System.EventHandler(this.TarihiPic_Click);
            // 
            // AşkPic
            // 
            this.AşkPic.Image = ((System.Drawing.Image)(resources.GetObject("AşkPic.Image")));
            this.AşkPic.Location = new System.Drawing.Point(441, 135);
            this.AşkPic.Name = "AşkPic";
            this.AşkPic.Size = new System.Drawing.Size(205, 150);
            this.AşkPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AşkPic.TabIndex = 0;
            this.AşkPic.TabStop = false;
            this.AşkPic.Click += new System.EventHandler(this.AşkPic_Click);
            // 
            // ŞiirPic
            // 
            this.ŞiirPic.Image = ((System.Drawing.Image)(resources.GetObject("ŞiirPic.Image")));
            this.ŞiirPic.Location = new System.Drawing.Point(652, 311);
            this.ŞiirPic.Name = "ŞiirPic";
            this.ŞiirPic.Size = new System.Drawing.Size(205, 146);
            this.ŞiirPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ŞiirPic.TabIndex = 0;
            this.ŞiirPic.TabStop = false;
            this.ŞiirPic.Click += new System.EventHandler(this.ŞiirPic_Click);
            // 
            // Aksiyonpic
            // 
            this.Aksiyonpic.Image = ((System.Drawing.Image)(resources.GetObject("Aksiyonpic.Image")));
            this.Aksiyonpic.Location = new System.Drawing.Point(9, 135);
            this.Aksiyonpic.Name = "Aksiyonpic";
            this.Aksiyonpic.Size = new System.Drawing.Size(215, 150);
            this.Aksiyonpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Aksiyonpic.TabIndex = 0;
            this.Aksiyonpic.TabStop = false;
            this.Aksiyonpic.Click += new System.EventHandler(this.Aksiyonpic_Click_1);
            // 
            // GerilimPic
            // 
            this.GerilimPic.Image = ((System.Drawing.Image)(resources.GetObject("GerilimPic.Image")));
            this.GerilimPic.Location = new System.Drawing.Point(441, 311);
            this.GerilimPic.Name = "GerilimPic";
            this.GerilimPic.Size = new System.Drawing.Size(205, 146);
            this.GerilimPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GerilimPic.TabIndex = 0;
            this.GerilimPic.TabStop = false;
            this.GerilimPic.Click += new System.EventHandler(this.GerilimPic_Click);
            // 
            // DramPic
            // 
            this.DramPic.Image = ((System.Drawing.Image)(resources.GetObject("DramPic.Image")));
            this.DramPic.Location = new System.Drawing.Point(230, 135);
            this.DramPic.Name = "DramPic";
            this.DramPic.Size = new System.Drawing.Size(205, 150);
            this.DramPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DramPic.TabIndex = 0;
            this.DramPic.TabStop = false;
            this.DramPic.Click += new System.EventHandler(this.DramPic_Click);
            // 
            // KorkuPic
            // 
            this.KorkuPic.Image = ((System.Drawing.Image)(resources.GetObject("KorkuPic.Image")));
            this.KorkuPic.Location = new System.Drawing.Point(652, 135);
            this.KorkuPic.Name = "KorkuPic";
            this.KorkuPic.Size = new System.Drawing.Size(205, 150);
            this.KorkuPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.KorkuPic.TabIndex = 0;
            this.KorkuPic.TabStop = false;
            this.KorkuPic.Click += new System.EventHandler(this.KorkuPic_Click);
            // 
            // DedektifiyePic
            // 
            this.DedektifiyePic.Image = ((System.Drawing.Image)(resources.GetObject("DedektifiyePic.Image")));
            this.DedektifiyePic.Location = new System.Drawing.Point(230, 311);
            this.DedektifiyePic.Name = "DedektifiyePic";
            this.DedektifiyePic.Size = new System.Drawing.Size(205, 146);
            this.DedektifiyePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DedektifiyePic.TabIndex = 0;
            this.DedektifiyePic.TabStop = false;
            this.DedektifiyePic.Click += new System.EventHandler(this.DedektifiyePic_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(75, 288);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Aksiyon";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(315, 288);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Dram";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(526, 288);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Aşk";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(756, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Korku";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(86, 460);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Tarihi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(756, 460);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "Şiir ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(298, 460);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "Dedektifye";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(526, 460);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "Gerilim";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(602, 10);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(252, 119);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(29, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(567, 69);
            this.label9.TabIndex = 2;
            this.label9.Text = "Kitap Konusu Seçin";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(339, 499);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 46);
            this.button1.TabIndex = 3;
            this.button1.Text = "Geri";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MenüForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 557);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DramPic);
            this.Controls.Add(this.GerilimPic);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.Aksiyonpic);
            this.Controls.Add(this.ŞiirPic);
            this.Controls.Add(this.AşkPic);
            this.Controls.Add(this.KorkuPic);
            this.Controls.Add(this.DedektifiyePic);
            this.Controls.Add(this.TarihiPic);
            this.Name = "MenüForm";
            this.Text = "Menü";
            ((System.ComponentModel.ISupportInitialize)(this.TarihiPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AşkPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ŞiirPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Aksiyonpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GerilimPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DramPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorkuPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DedektifiyePic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox TarihiPic;
        private System.Windows.Forms.PictureBox AşkPic;
        private System.Windows.Forms.PictureBox ŞiirPic;
        private System.Windows.Forms.PictureBox Aksiyonpic;
        private System.Windows.Forms.PictureBox GerilimPic;
        private System.Windows.Forms.PictureBox DramPic;
        private System.Windows.Forms.PictureBox KorkuPic;
        private System.Windows.Forms.PictureBox DedektifiyePic;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
    }
}