﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibaryProgram
{
    public class DreamDal
    {
        public List<Dream> GetAllDreams()
        {
            List<Dream> dreams = new List<Dream>();
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlcommand = new SqlCommand("Select * From Dreams ", sqlConnection);
            SqlDataReader sqlDataReader = sqlcommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Dream dream = new Dream
                {
                    Id = Convert.ToInt32(sqlDataReader["Id"]),
                    Name = sqlDataReader["Name"].ToString(),
                    WriterName = sqlDataReader["WriterName"].ToString(),
                    WriterSurname = sqlDataReader["WriterSurname"].ToString(),
                    NumberOfPages = Convert.ToInt32(sqlDataReader["NumberOfPages"]),
                    Summary = sqlDataReader["Summary"].ToString()
                };
                dreams.Add(dream);
            }
            return dreams;

        }
        public void AddDream(Dream dream)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO Dreams (Name, WriterName, WriterSurname, NumberOfPages, Summary) VALUES (@p1,@p2,@p3,@p4,@p5)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", dream.Name);
            sqlCommand.Parameters.AddWithValue("@p2", dream.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", dream.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", dream.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", dream.Summary);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }
        public void UpdateDream(Dream dream)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("UPDATE Dreams SET Name=@p1, WriterName=@p2, WriterSurname=@p3, NumberOfPages=@p4, Summary=@p5 WHERE Id=@Id", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", dream.Name);
            sqlCommand.Parameters.AddWithValue("@p2", dream.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", dream.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", dream.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", dream.Summary);
            sqlCommand.Parameters.AddWithValue("@Id", dream.Id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }
        public void DeleteDream(int id)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Delete From Dreams Where Id=@p1", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }

    }
}
