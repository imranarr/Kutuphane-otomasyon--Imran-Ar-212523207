﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibaryProgram
{
    public class FearDal
    {
        public List<Fear> GetAllFear()
        {
            List<Fear> fears = new List<Fear>();
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlcommand = new SqlCommand("Select * From Fears ", sqlConnection);
            SqlDataReader sqlDataReader = sqlcommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Fear fear = new Fear
                {
                    Id = Convert.ToInt32(sqlDataReader["Id"]),
                    Name = sqlDataReader["Name"].ToString(),
                    WriterName = sqlDataReader["WriterName"].ToString(),
                    WriterSurname = sqlDataReader["WriterSurname"].ToString(),
                    NumberOfPages = Convert.ToInt32(sqlDataReader["NumberOfPages"]),
                    Summary = sqlDataReader["Summary"].ToString()
                };
                fears.Add(fear);
            }
            return fears;

        }
        public void AddFear(Fear fear)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO Fears (Name, WriterName, WriterSurname, NumberOfPages, Summary) VALUES (@p1,@p2,@p3,@p4,@p5)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", fear.Name);
            sqlCommand.Parameters.AddWithValue("@p2", fear.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", fear.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", fear.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", fear.Summary);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }
        public void UpdateFear(Fear fear)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Update Fears set (Nanme, WriterName,WriterSurname,NumberOfPages, Summary,Id)VALUES(@p1,@p2,@p3,@p4,@p5,id)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", fear.Name);
            sqlCommand.Parameters.AddWithValue("@p2", fear.WriterName);
            sqlCommand.Parameters.AddWithValue("@p3", fear.WriterSurname);
            sqlCommand.Parameters.AddWithValue("@p4", fear.NumberOfPages);
            sqlCommand.Parameters.AddWithValue("@p5", fear.Summary);
            sqlCommand.Parameters.AddWithValue("@Id", fear.Id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }
        public void DeleteFear(int id)
        {
            SqlConnection sqlConnection = new SqlConnection("Server=Azat; Initial Catalog=DbLibrary; integrated security=true");
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("Delete From Fears Where Id=@p1", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@p1", id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

        }

    }
}
