USE [master]
GO

/****** Object:  Database [DbLibrary]    Script Date: 23.05.2023 01:08:12 ******/
DROP DATABASE [DbLibrary]
GO

